<?php
	session_start();
	require_once("../modele/connect.php");
	//var_dump($_GET["identifiant"]);
	$idGroupe = $_GET["identifiant"];
  $pseudo = $_SESSION['pseudo'];
	$bdd->exec("INSERT INTO groupeinscrit(pseudo, nomGroupe) VALUES ('$pseudo', '$idGroupe')");

	header("Location: pageGroupe.php?identifiant=$idGroupe");
	exit;
?>
