<?php
session_start();
$auteur = $_POST['auteur'];
$groupe = $_POST['groupe'];
$invite = $_POST['invite'];

require_once("../modele/connect.php");

$reponse = $bdd->query("SELECT * FROM membres WHERE pseudo = $invite");

if(!empty($reponse){
	$donnees = $reponse->fetch();
}

include ("mailinvite.php?identifiant=<?php echo $groupe; ?>&desti=<?php echo $donnees["mail"]; ?>&auteur=<?php echo $auteur; ?>");

header("Location: pageGroupe.php?identifiant=$groupe");
exit;
?>
