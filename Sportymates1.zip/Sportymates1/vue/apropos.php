<?php
session_start();
?>

<head>
  <meta charset="utf-8" />
  <link rel="stylesheet" href="../style/apropos.css" />
  <link rel="stylesheet" href="../style/accueilv2.css" />
  <link rel="icon" type="image/ico" href=logo3.png />
  <title>Sportymates</title>
</head>

<body>
  <div id='wrapper'>
    <header style="background-image:url(../images/activites.jpg)">
        <?php
        if(empty($_SESSION['pseudo'])){
          include("banniere_entete.php");
          include("nav.php");
        }else{
          include("banniere_entete2.php");
          include("nav.php");
        }
        ?>
    </header>

<div id="totpropos">
 <div id="apropos">
 <div class="photos">
   <img src="http://localhost/Sportymates1/images/lieux.jpeg" alt="photo lieu">
 </div>
   <div class="texte">
     <h2>A propos</h2>
     <p> On Sportymates you can find a sport partner near you. </br>
       No matter if you are looking for a dancing partner, walking partner,</br>
      a partner to play golf with, or any other sport: with more than</br>
       ten thousand members, the chances are high that you will find a </br>
       matching sport partner. Sportymates is set up for this specific reason,</br>
        namely matching sport partners in their local areas. This is why it has</br>
         been successful for years already .You can find a sport partner near you. </br>
           No matter if you are looking for a dancing partner, walking partner,</br>
          a partner to play golf with, or any other sport: with more than</br>
           ten thousand members, the chances are high that you will find a </br>
           matching sport partner. Sportymates is set up for this specific reason,</br>
            namely matching sport partners in their local areas. This is why it has</br>
             been successful for years already .</p>
  </div>
</div>
</div>

 <di
<?php
include('bas.php');
?>
</div>
</body>
