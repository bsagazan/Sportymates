<?php
	session_start();
	require_once("../modele/connect.php");
	//var_dump($_GET["identifiant"]);
	$idGroupe = $_GET["identifiant"];
	$pseudo=$_SESSION["pseudo"];

	$bdd->exec("DELETE FROM groupeinscrit WHERE nomGroupe = '$idGroupe' AND pseudo = '$pseudo'");

	$reponse = $bdd->query("SELECT * FROM listeattente WHERE nomGroupe = '$idGroupe'");

	if (!empty($reponse)){
		while($donnees = $reponse->fetch()){

			include ('mailalerte.php?identifiant=<?php echo $idGroupe; ?>&desti=<?php echo $donnees['mail']; ?>');
			$bdd->exec("DELETE FROM listeattente WHERE nomGroupe=$idGroupe AND pseudo =$_SESSION["pseudo"]");
		}
	}
?>

<?php
	header("Location: pageGroupe.php?identifiant=$idGroupe");
	exit;
?>
