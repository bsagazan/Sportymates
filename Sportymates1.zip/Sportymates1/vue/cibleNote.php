<?php
session_start();
require_once("../modele/connect.php");

$groupe = $_POST['groupe'];
$auteur = $_POST['auteur'];
$note = $_POST['note'];

$presence = 0;

$reponse = $bdd->query("SELECT * FROM noterGroupe WHERE nomGroupe = $groupe AND pseudo = $auteur");

if (!empty($reponse)) {
	$presence = 1;
}

if ($presence == 1) {
	$bdd->exec("UPDATE notergroupe SET note = $note WHERE nomGroupe = $groupe AND pseudo = $auteur");
}

if ($presence == 0) {
	$bdd->exec("INSERT INTO notergroupe (nomGroupe, pseudo, note) VALUES ('$groupe', '$auteur', '$note')");
}

header("Location: pageGroupe.php?identifiant=$groupe");
exit;

?>
