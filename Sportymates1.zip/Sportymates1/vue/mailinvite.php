<?php
	session_start();

	$idGroupe = $_GET["identifiant"];
	$desti = $_GET["desti"];
	$auteur = $_GET["auteur"];

	$header="MIME-Version: 1.0\r\n";
	$header.='From:"SPORTYMATES"<support@sportymates.com>'."\n";
	$header.='Content-Type:text/html; charset="uft-8"'."\n";
	$header.='Content-Transfer-Encoding: 8bit';

$message='
	<html>
		<body>
			<div align="center">
				<img src="http://www.sortir43.com/sites/default/files/styles/bani_re/public/Sports.jpg?itok=oGa6iDWF"/>
				<br />
				L\'utilisateur <?php echo $auteur; ?> vous a invité à rejoindre le groupe <?php echo $idGroupe; ?>. Cliquez <a href = "localhost/Sportymates/groupe?identifiant=$idGroupe.php"> ici </a> pour accéder à la page du groupe et le rejoindre !
				<br />
			</div>
		</body>
	</html>
	';

	mail($desti, "Invitation à rejoindre un groupe", $message, $header);
?>