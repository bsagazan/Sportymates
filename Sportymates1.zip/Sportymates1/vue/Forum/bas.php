<!--Footer-->


<div id=footer>
    <div class="Autres pages">
        <h1>Autres pages</h1>
        <p> <a href="../vue/apropos.php">A propos</a><br>
            <a href="http://localhost/Sportymates1/vue/pageaide.php">Aide</a><br>
            <a href="http://localhost/Sportymates1/vue/Forum/index.php">Forum</a><br>
            <a href="http://localhost/Sportymates1/vue/nouscontacter.php">Nous contacter</a></p>
    </div>
    <div class="Réseaux sociaux">
        <h1>Réseaux sociaux</h1>
        <a href="https://www.facebook.com/Sportymates-1116430581702970/?ref=bookmarks"><img src="../../images/logo_facebook.png" alt="LogoFacebook" /></a>
        <a href="https://twitter.com/sportymates?lang=fr"><img src="../../images/logo_twitter.png" alt="Logotwitter" /></a>
        <a href="https://plus.google.com/"><img src="../../images/logo_googleplus.png" alt="Logo google plus" /></a>
    </div>
    <div class="Copyright_et_mention_legales">
        <h1>Copyright et mention légales</h1>
        <p>© 2016  Sportymates</p>
    </div>
</div>

<!--/*Footer*/
#footer
{
    min-width: 1110px;
    padding-right: 10px;
    padding-bottom: 10px;
    display: flex;
    flex-direction: column;
    text-align: center;
    background: url(../images/fond_footer.jpg)repeat;
}
#footer h1
{
    font-size:18px;
    margin-left: 50px;
    color: white;
    padding-top: 15px;
    font-family: anonymousregular;
}
#footer a
{
    display: inline-block;
    float: center;
    padding-top: 5px;
    color: grey;
    font-style: italic;
    padding-bottom: 10px;
    margin-left: 20px;
}
#footer p
{
    margin-left: 30px;
    color: grey;
}
#footer img
{
    flex-flow: column;
    margin-left:8px;
    margin-right: 15px;
    padding-bottom:5px;
    padding-right:5px;
    padding-top: 10px;
    width: 30px;
    height: 30px;
}
/*fin footer*/-->
