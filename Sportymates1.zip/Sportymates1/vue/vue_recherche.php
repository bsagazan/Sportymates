<?php session_start();?>
<!DOCTYPE HTML>
<html>
    <head>
        <meta charset="utf-8"/>
        <link rel="stylesheet" type="text/css" href="../style/accueilv2.css"/>
        <link rel="stylesheet" type="text/css" href="../style/styleRech.css"/>
        <title>Recherche - Sportymates</title>
        <link rel='icon' type="image/ico" href="images/Logo1.png"/>
    </head>

    <body>
        <div id="wrapper">
            <header style="background-image:url(../images/header-activite.jpg)">
                <?php
                include("banniere_entete.php");
                include("nav.php");
                ?>
            </header>
            <section id="recherche">
                <h1>Recherche</h1>

                <form name="Recherche" action="../controleur/recherche.php" method="post" >
                    <input type="search" name="champ" placeholder="Que recherchez-vous ?" size="40" maxlength="50" />
                    <input type="submit" class="bouton" value="Rechercher" />

                </form>
            </section>
            <section id="bloc_resultat">
                <p><?php echo $msgResultat;?></p>
                <?php
                if(isset($_GET['theme'])){
                    if($_GET['theme']=="groupe"){
                        echo "<div class='theme'>";
                        echo " <h2>Groupe</h2>";
                        if($nb_result_groupe !=0){

                            while($donnees = $rep_groupe->fetch()){
                ?>
                <p class="resultats">
                    <a href="../vue/modele.php?groupe=<?php echo $donnees['nomGroupe'];?>"><?php echo $donnees['nomGroupe'];?> </a><br>
                    Sport : <?php echo $donnees['nomSport'];?>
                    Club : <?php echo $donnees['nomClub'];?>
                    Ville : <?php echo $donnees['ville'];?>

                </p>

                <?php
                            }

                        }
                        else{
                            echo "<p class='aucunResultat'>Aucun résultat</p>";
                        }
                        echo "</div>";

                    }

                    if($_GET['theme']=="club"){
                        echo "<div class='theme'>";
                        echo " <h2>Club</h2>";
                        if($nb_result_club !=0){

                            while($donnees = $rep_club->fetch()){
                ?>
                <p class="resultats">
                    <a href="../vue/modele.php?groupe=<?php echo $donnees['nomClub'];?>"><?php echo $donnees['nomClub'];?> </a><br>
                    Adresse : <?php echo $donnees['adresse'];?>
                </p>

                <?php
                            }

                        }
                        else{
                            echo "<p class='aucunResultat'>Aucun résultat</p>";
                        }
                        echo "</div>";

                    }

                    if($_GET['theme']=="sport"){
                        echo "<div class='theme'>";
                        echo " <h2>Sport</h2>";
                        if($nb_result_club !=0){

                            while($donnees = $rep_club->fetch()){
                ?>
                <p class="resultats">
                    <a href="../vue/modele.php?groupe=<?php echo $donnees['nomSport'];?>"><?php echo $donnees['nomSport'];?> </a><br>
                </p>

                <?php
                            }

                        }
                        else{
                            echo "<p class='aucunResultat'>Aucun résultat</p>";
                        }
                        echo "</div>";

                    }
                }
                else{


                    if($nbreTotal != 0){
                        echo "<div class='theme'>";
                        echo " <h2>Groupe</h2>";
                        if($nb_result_groupe !=0){

                            while($donnees = $rep_groupe->fetch()){
                ?>
                <p class="resultats">
                    <a href="../vue/modele.php?groupe=<?php echo $donnees['nomGroupe'];?>"><?php echo $donnees['nomGroupe'];?> </a><br>
                    Sport : <?php echo $donnees['nomSport'];?>
                    Club : <?php echo $donnees['nomClub'];?>
                    Ville : <?php echo $donnees['ville'];?>

                </p>

                <?php
                            }

                        }
                        else{
                            echo "<p class='aucunResultat'>Aucun résultat</p>";
                        }
                        echo "</div>";


                        echo "<div class='theme'>";
                        echo " <h2>Club</h2>";
                        if($nb_result_club !=0){

                            while($donnees = $rep_club->fetch()){
                ?>
                <p class="resultats">
                    <a href="../vue/modele.php?groupe=<?php echo $donnees['nomClub'];?>"><?php echo $donnees['nomClub'];?> </a><br>
                    Adresse : <?php echo $donnees['adresse'];?>
                </p>

                <?php
                            }

                        }
                        else{
                            echo "<p class='aucunResultat'>Aucun résultat</p>";
                        }
                        echo "</div>";

                        echo "<div class='theme'>";
                        echo " <h2>Sport</h2>";
                        if($nb_result_sport !=0){

                            while($donnees = $rep_sport->fetch()){
                ?>
                <p class="resultats">
                    <a href="../vue/modele.php?groupe=<?php echo $donnees['nomSport'];?>"><?php echo $donnees['nomSport'];?> </a><br>
                </p>

                <?php
                            }

                        }
                        else{
                            echo "<p class='aucunResultat'>Aucun résultat</p>";
                        }
                        echo "</div>";

                    }
                }


                ?>
            </section>
            <?php include("bas.php");?>
        </div>

    </body>




</html>
