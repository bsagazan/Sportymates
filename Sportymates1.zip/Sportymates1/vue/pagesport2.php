<?php
session_start();
require_once("../modele/connect.php");
 ?>
<!DOCTYPE HTML>
<html>
    <head>
        <meta charset="utf-8"/>
        <title>Sportymates</title>
        <link rel="stylesheet" href="../style/pagesport.css"/>
        <link rel="stylesheet" href="../style/accueilv2.css" />
        <link rel='icon' type="image/ico" href="../images/Logo1.png"/>
    </head>

    <body>
        <div id="wrapper">
          <?php
        $donnees = $rep2->fetch();
          ?>
            <header style="background-image : url(../vue/Sports/img-Sports/<?php echo $donnees['imgSports'];?>)">

              <?php
              if(empty($_SESSION['pseudo'])){
                include("banniere_entete.php");
              }else{
                include("banniere_entete2.php");
              }
              ?>
                <div id="Titre">
                    <h1><?php //echo $nomSport; ?></h1><br>
                </div>
                <?php include("nav.php");?>
            </header>
              <br/>
             <div id="haut">
                <h1>N'hésitez plus et rejoignez nous!</h1></br>
            </div>
             <br/>
             <div id="haut1">
              <?php if(!empty($_SESSION['pseudo'])){?>
             <input class="buttoncreergroupe" type="submit" value="Créer un groupe" onClick="window.location = '../vue/creerGroupe.php'" ></code>
             <input class="buttonchercher" type="submit" value="Rechercher un groupe" ></code>
             <?php }?>
            </div>
            <br/>

            <div id="parties">
              <?php
              while ($donnees = $rep->fetch()) {
              ?>
              <div class="Sport">
              <h2>Sport</h2>
              <p><?php echo $donnees["descriptionSport"]; ?></p>
             </div>
             <br/>
               <?php
             }?>
            </div>
            <br/>

            <div id="titreevents">
               <h2>Evenements a venir</h2>
            </div>
            <?php
            while ($donnees = $rep1->fetch()) {
              ?>
              <div id="events">
              <img src="../vue/Evenement/img-evenement/<?php echo $donnees['imgEvenement'];?>"/>
           </div>
           <?php
           }
           ?>
             <div id="titregroupes">
              <h2>Nos groupes</h2>
            </div>
            <?php
              while ($donnees = $rep3->fetch()) {?>
                <div id="groupe">
                <figure>
                  <a href="../vue/pageGroupe.php?identifiant=<?php echo $donnees['nomGroupe'];?>">
                <img src="../vue/Groupes/img-Groupes/<?php echo $donnees['imgGroupe'];?>"/><br/>
                <figcaption align="center"> <?php echo $donnees['nomGroupe']?></figcaption>
              </a>
              </figure>

                </div>
                <?php
                }
                ?>

            <?php
            include('bas.php');
            ?>
        </div>
    </body>
</html>
