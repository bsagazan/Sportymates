<?php
session_start();
require_once("../modele/connect.php");

 ?>
<html>
  <head>
      <meta charset="utf-8" />
      <link rel="stylesheet" href="../style/accueilv2.css" />
      <link rel="stylesheet" href="../style/admin2.css" />
      <title>Sportymates</title>
      <link rel="icon" type="image/ico" href=logo3.png />
  </head>

<body>
    <div id='wrapper'>
      <header style="background-image:url(../images/friends.jpg)">
        <?php
        if(empty($_SESSION['pseudo'])){
          include("banniere_entete.php");
          include("nav.php");
        }else{
          include("banniere_entete2.php");
          include("nav.php");
        }
        ?>
      </header>

        <section id="recherche">
          <h1 id="question">Modifier les donnees groupes</h1>
        </section>

<?php

    $reponse = $bdd->query('SELECT * FROM groupe WHERE nomGroupe=\''.$_GET['groupe'].'\'');

    while ($donnees=$reponse->fetch()){
?>
  <div align=center>
  <form name="ma_form" method="post" action="../controleur/modif2.php?groupe=<?php echo $donnees['nomGroupe'] ?>" >
    <table>
      <br/>
      <tr>
        <td>Nom du groupe</td>
        <td><input type="text" name="ngroupe" value='<?php echo $donnees['nomGroupe'] ?>'></input></td>
      </tr>
      <tr>
        <td>Leader</td>
        <td><input type="text" name="lead" value='<?php echo $donnees['leader'] ?>'></input></td>
      </tr>
      <tr>
        <td>Nom du sport</td>
        <td><input type="text" name="sport" value='<?php echo $donnees['nomSport'] ?>'></input></td>
      </tr>
      <tr>
        <td>idClub</td>
        <td><input type="int" name="idClub" value='<?php echo $donnees['idClub'] ?>'></input></td>
      </tr>
      <tr>
        <td>Ville</td>
        <td><input type="text" name="ville" value='<?php echo $donnees['ville'] ?>'></input></td>
      </tr>
      <tr>
        <td>Niveau</td>
        <td><input type="int" name="niv" value='<?php echo $donnees['niveau'] ?>'></input></td>
      </tr>
      <tr>
        <td>Nombre max</td>
        <td><input type="int" name="nbmax" value='<?php echo $donnees['nbreMax'] ?>'></input></td>
      </tr>
      <tr>
        <td>Description</td>
        <td><textarea type="message" rows="10" cols="70" name="descript" value='<?php echo $donnees['description'] ?>'></textarea></td>
      </tr>
      <tr>
        <td>Image</td>
        <td><input type="text" name="img" value='<?php echo $donnees['imgGroupe'] ?>'></input></td>
      </tr>

    </table>
    <input type="submit" value="Valider" class='bouton' />
  </form>
</div>
  <br/>

</div>

<?php
}
?>
<?php
include('bas.php');
?>
</body>
