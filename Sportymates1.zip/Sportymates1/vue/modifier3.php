<?php
session_start();
require_once("../modele/connect.php");

 ?>
<html>
<head>
    <meta charset="utf-8" />
    <link rel="stylesheet" href="../style/accueilv2.css" />
    <link rel="stylesheet" href="../style/admin2.css" />
    <title>Sportymates</title>
    <link rel="icon" type="image/ico" href=logo3.png />
</head>

<body>
  <div id='wrapper'>
    <header style="background-image:url(../images/friends.jpg)">
      <?php
      if(empty($_SESSION['pseudo'])){
        include("banniere_entete.php");
        include("nav.php");
      }else{
        include("banniere_entete2.php");
        include("nav.php");
      }
      ?>
    </header>

      <section id="recherche">
        <h1 id="question">Modifier les donnees clubs</h1>
      </section>
<?php
require_once("../modele/connect.php");

    $reponse = $bdd->query('SELECT * FROM club WHERE idClub=\''.$_GET['club'].'\'');

    while ($donnees=$reponse->fetch()){



?>
<div align=center>
  <form name="ma_form" method="post" action="../controleur/modif3.php?club=<?php echo $donnees['idClub'] ?>" >
    <table>
      <br/>
      <tr>
        <td>Nom du club</td>
        <td><input type="text" name="nclub" value='<?php echo $donnees['nomClub'] ?>'></input></td>
      </tr>
      <tr>
        <td>Adresse</td>
        <td><input type="text" name="adresse" value='<?php echo $donnees['adresse'] ?>'></input></td>
      </tr>
      <tr>
        <td>Téléphone</td>
        <td><input type="number" name="tel" value='<?php echo $donnees['telephone'] ?>'></input></td>
      </tr>
      <tr>
        <td>Heure d'ouverture</td>
        <td><input type="time" name="houverture" value='<?php echo $donnees['heureOuverture'] ?>'></input></td>
      </tr>
      <tr>
        <td>Heure de fermeture</td>
        <td><input type="time" name="hfermeture" value='<?php echo $donnees['heureFermeture'] ?>'></input></td>
      </tr>
      <tr>
        <td>Jour d'ouverture</td>
        <td><input type="text" name="jouverture" value='<?php echo $donnees['jourOuverture'] ?>'></input></td>
      </tr>
      <tr>
        <td>Jour de fermeture</td>
        <td><input type="text" name="jfermeture" value='<?php echo $donnees['jourFermeture'] ?>'></input></td>
      </tr>
      <tr>
        <td>Description</td>
        <td><textarea type="message" rows="10" cols="70" name="descript" value='<?php echo $donnees['description'] ?>'></textarea></td>
      </tr>

    </table>
    <input type="submit" value="Valider" class="bouton" />
    <br/>
  </form>
  <br/>

</div>

<?php
}
?>
<?php
include('bas.php');
?>
</body>
