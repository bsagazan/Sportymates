<?php
	session_start();
	require_once("../modele/connect.php");

	$idGroupe = $_GET["identifiant"];
	$utilisateur = $_SESSION["pseudo"];

	$bdd->exec("INSERT INTO listeattente(nomUtilisateur, nomGroupe, dateHeure) VALUES ('$utilisateur', '$idGroupe', NOW())");

	header("Location: pageGroupe.php?identifiant=$idGroupe");
	exit;
?>
