<?php
session_start();
require_once("../modele/connect.php");

 ?>
<html>
<head>
    <meta charset="utf-8" />
    <link rel="stylesheet" href="../style/accueilv2.css" />
    <link rel="stylesheet" href="../style/admin2.css" />
    <title>Sportymates</title>
    <link rel="icon" type="image/ico" href=logo3.png />
</head>

<body>
  <div id='wrapper'>
    <header style="background-image:url(../images/friends.jpg)">
      <?php
      if(empty($_SESSION['pseudo'])){
        include("banniere_entete.php");
        include("nav.php");
      }else{
        include("banniere_entete2.php");
        include("nav.php");
      }
      ?>
    </header>

      <section id="recherche">
        <h1 id="question">Administrer l'aide</h1>
      </section>
<?php
require_once("../modele/connect.php");

    $reponse = $bdd->query('SELECT * FROM rubrique WHERE idRubrique=\''.$_GET['rubrique'].'\'');

    while ($donnees=$reponse->fetch()){



?>
<div align=center>
  <form name="form" method="post" action="../controleur/modif4.php?rubrique=<?php echo $donnees['idRubrique'] ?>" >
    <table>
      <br/>
      <tr>
        <td>IdRubrique</td>
        <td><input type="number" name="idRubrique" value='<?php echo $donnees['idRubrique'] ?>'></input></td>
      </tr>
      <tr>
        <td>Réponses</td>
        <td><textarea type="message"  rows="10" cols="70" name="reponse" value='<?php echo $donnees['reponse'] ?>'></textarea></td>
      </tr>
      <tr>
        <td>Questions</td>
        <td><textarea type="message"  rows="10" cols="70" name="question" value='<?php echo $donnees['question'] ?>'></textarea></td>
      </tr>
      <tr>
        <td>Catégorie</td>
        <td><input type="text" name="categorie" value='<?php echo $donnees['categorie'] ?>'></input></td>
      </tr>
      <tr>

    </table>
    <input type="submit" value="Valider" class="bouton" />
    <br/>
  </form>
  <br/>

</div>

<?php
}
?>
<?php
include('bas.php');
?>
</body>
