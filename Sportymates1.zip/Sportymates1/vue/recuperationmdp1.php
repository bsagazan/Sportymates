<?php
session_start();
$bdd = new PDO('mysql:host=localhost;dbname=sportymates', 'root', '');

if(isset($_GET['section'])){
  $section = htmlspecialchars($_GET['section']);
}else{
    $section= "";
}
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8"/>
        <link rel="stylesheet" href="../style/accueil2.css" />
        <link rel="stylesheet" href="../style/recupmdp.css" />
        <title>Récupération de mdp - Sportymates </title>
        <link rel='icon' type="image/ico" href="../images/log.png"/>
    </head>

    <body>
        <div id="bloc_page">
              <div id='wrapper'>

                <header style="background-image:url(../images/activites.jpg)">
                    <?php
                    include("banniere_entete.php");
                    include("nav.php");
                    ?>
              </header>
                <div id="all">
                <br/>  <h2 class="titre">Récupération de mot de passe</h2><br/>

                <?php if($section == 'code') { ?>
                <strong>  Un code de vérification vous a été envoyé par mail: <?= $_SESSION['recup_mail'] ?></strong><br/>
                  <br/>
                  <form method="post" action="recupmdp.php">
                    <label class='mail1'>Votre adresse mail : </label>
                     <input class="mail" type="text" placeholder="Code de vérification" name="verif_code"/><br/>
                     <br/>
                     <input class="valider" type="submit" value="Valider" name="verif_submit"/><br/>
                  </form>

                  <?php } elseif($section == "changemdp") { ?>
                <strong>  Nouveau mot de passe pour <?= $_SESSION['recup_mail'] ?> </strong>
                  <form method="post"  action="recupmdp.php"><br/>
                    <label class='mail1'>Votre nouveau mot de passe : </label>
                     <input class="mail"type="password" placeholder="Nouveau mot de passe" name="change_mdp"/><br/>
                      <br/>
                     <label class='mail1'>Confirmation de votre nouveau mot de passe : </label>
                     <input class="mail" type="password" placeholder="Confirmation du mot de passe" name="change_mdpc"/><br/>
                      <br/>
                     <input class="valider" type="submit" value="Valider" name="change_submit"/><br/>
                  </form>

                  <?php } else { ?>
                  <form method="post"  action="recupmdp.php"><br/>
                     <label class='mail1'>Votre adresse mail : </label>
                     <input class ='mail'type="email" placeholder="Votre adresse mail" name="recup_mail"/><br/>
                     <br/><input class='valider' type="submit" value="Valider" name="recup_submit"/><br/>
                  </form>
                  <?php } ?>

                  <?php if(isset($error)) { echo '<span style="color:red">'.$error.'</span>'; } else { echo ""; } ?>
                   <br/><br/><br/>
                    <?php
                    include('bas.php');
                    ?>
                  </div>
               </div>
              </body>
              </html>
