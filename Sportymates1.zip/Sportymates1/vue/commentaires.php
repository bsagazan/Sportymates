<meta charset="utf-8" />
<?php
$bdd = new PDO('mysql:host=localhost;dbname=sportymates;charset=utf8','root','');

  if(isset($_POST['envoyer'])) {
     if(isset($_POST['auteur'],$_POST['contenu']) AND !empty($_POST['auteur']) AND !empty($_POST['contenu'])) {
                $auteur = htmlspecialchars($_POST['auteur']);
                $contenu = htmlspecialchars($_POST['contenu']);
                if(strlen($auteur) < 25) {
                   $ins = $bdd->prepare('INSERT INTO commentaire (auteur, contenu) VALUES (?,?)');
                   $ins->execute(array($auteur,$contenu));
                   $c_msg = "<span style='color:green'>Votre commentaire a bien été posté</span>";
                } else {
                   $c_msg = "Erreur: Le pseudo doit faire moins de 25 caractères";
                }
             } else {
                $c_msg = "Erreur: Tous les champs doivent être complétés";
             }
          }

  ?>


  <h2>Commentaires:</h2>
  <form method="POST">
 <input type="text" name="auteur" placeholder="Votre pseudo" /><br /><br/>
 <textarea name="contenu" placeholder="Votre commentaire..."></textarea><br /><br/>
 <input type="submit" value="Poster mon commentaire" name="envoyer" />
</form>
<?php if(isset($c_msg)) { echo $c_msg; } ?>
<br /><br />
