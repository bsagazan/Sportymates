<?php
session_start();
require_once("../modele/connect.php");

var_dump($_POST['contenuCom']);
$contenu = $_POST['contenuCom'];
$auteur = $_POST['auteur'];
$groupe = $_POST['groupe'];

$bdd->exec("INSERT INTO commentaire (contenu, dateHeure, nomGroupe, auteur) VALUES ('$contenu', NOW(), '$groupe', '$auteur')");

header("Location: ../vue/pageGroupe.php?identifiant=$groupe");
exit;
?>
