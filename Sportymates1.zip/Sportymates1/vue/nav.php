<!--Menu-->

<div id="Menu">
    <nav>
        <ul>
            <li><a href="../vue/accueilv2.php">Accueil</a></li>
            <li><a href="../vue/groupesv2.php">Groupes</a></li>
            <li><a href="../vue/pagesports.php">Sports</a></li>
            <li><a href="../vue/Clubs.php">Clubs</a></li>
            <li><a href="../vue/pageAide.php">Aide</a></li>
            <li><a href="../vue/Forum/index.php">Forum</a></li>
        </ul>
    </nav>
    <form name="Recherche simple" id ="formRechSimple" action="../controleur/recherche.php">
        <input type="search" name="champ" placeholder="Que recherchez vous ?" size="40"/>
        <input type="submit" name="bouton" class="bouton" value="Rechercher"/>
    </form>
</div>
