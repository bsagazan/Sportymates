<?php
session_start();
?>
<head>
  <meta charset="utf-8" />
  <link rel="stylesheet" href="../style/accueilv2.css" />
  <link rel="stylesheet" href="../style/pagesports.css" />
  <link rel="icon" type="image/ico" href="../images/logo3.png" />
  <title>Page sports-Sportymates</title>
</head>

<body>
  <div id='wrapper'>
    <header style="background-image:url(../images/activites.jpg)">
      <?php
      if(empty($_SESSION['pseudo'])){
        include("banniere_entete.php");
        include("nav.php");
      }else{
        include("banniere_entete2.php");
        include("nav.php");
      }
      ?>
    </header>

     <div id="titresection">
         <h2>Explorer nos differents sports</h2>
         <p>Découvre tous nos sports</p>
    </div>

    <section id="bloc-sports">

                 <div class="sports">

                     <a href='../controleur/sports.php?sport=Natation' class="rubrique" style="background-image:url(../images/SA.jpg)">
                     <h3>Natation</h3></br>
                     </a>

                     <a href='../controleur/sports.php?sport=Waterpolo'class="rubrique" style="background-image:url(../images/waterpolo1.jpg)">
                     <h3>Waterpolo</h3></br>
                     </a>

                     <a href='../controleur/sports.php?sport=Volley'class="rubrique" style="background-image:url(../images/SD.jpg)">
                     <h3>Volley</h3></br>
                     </a>

                     <a href='../controleur/sports.php?sport=Course' class="rubrique" style="background-image:url(../images/course.jpg)">
                     <h3> Course</h3></br>
                     </a>

                  </div>

                  <div class="sports">

                    <a href='../controleur/sports.php?sport=Football' class="rubrique" style="background-image:url(../images/football.jpg)">
                    <h3>Football</h3></br>
                    </a>

                    <a href='../controleur/sports.php?sport=Handball'class="rubrique" style="background-image:url(../images/handball.png)">
                    <h3>Handball</h3></br>
                    </a>

                    <a href='../controleur/sports.php?sport=Basket'class="rubrique" style="background-image:url(../images/SB.jpeg)">
                    <h3>Basket</h3></br>
                    </a>

                    <a href='../controleur/sports.php?sport=Rugby'class="rubrique" style="background-image:url(../images/rugby.jpg)">
                    <h3>Rubgy</h3></br>
                    </a>

               </div>

               <div class="sports">

                 <a href='../controleur/sports.php?sport=Tennis'class="rubrique" style="background-image:url(../images/SG.jpg)">
                 <h3>Tennis</h3></br>
                 </a>

                <a href='../controleur/sports.php?sport=Badminton'class="rubrique" style="background-image:url(../images/badminton.jpg)">
                <h3>Badminton</h3></br>
                </a>

                <a href='../controleur/sports.php?sport=Golf'class="rubrique" style="background-image:url(../images/golf.jpg)">
                <h3>Golf</h3></br>
                </a>

                <a href='../controleur/sports.php?sport=Baseball'class="rubrique" style="background-image:url(../images/baseball.jpg)">
                <h3>Baseball</h3></br>
                </a>

            </div>

            <div class="sports">

                <a href='../controleur/sports.php?sport=Escrime' class="rubrique" style="background-image:url(../images/escrime.jpg)">
                <h3>Escrime</h3></br>
                </a>

                <a href='../controleur/sports.php?sport=Athletisme'class="rubrique" style="background-image:url(../images/SE.jpg)">
                <h3>Athlétisme</h3></br>
                </a>

                <a href='../controleur/sports.php?sport=Musculation'class="rubrique" style="background-image:url(../images/SF.jpg)">
                <h3>Musculation</h3></br>
                </a>

                <a href="../controleur/sports.php?sport=Danse" class="rubrique" style="background-image:url(../images/danse.jpg)">
                <h3>Danse</h3></br>
                </a>

             </div>

</section>

     <?php include('bas.php');  ?>
  </div>
</body>
