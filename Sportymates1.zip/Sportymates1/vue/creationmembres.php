<?php
//controleur
// Vérification de la validité des informations

$pass_hache = sha1('gz'.$_POST['pass']);

//modele
// Insertion
$req = $bdd->prepare('INSERT INTO membres(Nom,Prenom,Pays,Ville,Datedenaissance,Adressemail,mdp,nomutilisateur,CodePostal,Administrateur,interet,civilite) VALUES(:Nom,:Prenom,:Pays,:Ville,:Datedenaissance,:Adressemail,:mdp,:nomutilisateur,:CodePostal,:Administrateur,:interet,:civilite, CURDATE())');
$req->execute(array(
    'Nom' => $nom,
    'Prenom' =>$Prenom,
    'Pays' => $Pays,
    'Ville' => $ville,
    'Datedenaissance' =>$Datedenaissance,
    'Adressemail' => $Adressemail,
    'mdp' => $mdp,
    'nomutilisateur' =>$nomutilisateur,
    'CodePostal' => $CodePostal,
    'Administrateur' => $Administrateur,
    'interet' =>$interet,
    'civilite' => $civilite, ));
