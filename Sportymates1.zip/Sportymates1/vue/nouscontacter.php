<?php
session_start();
require_once("../modele/connect.php");
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <link rel="stylesheet" href="../style/nouscontacter.css" />
        <link rel="stylesheet" href="../style/accueilv2.css" />
        <title>Sportymates</title>
        <link rel="icon" type="image/ico" href=logo3.png />
    </head>

    <body>
      <div id='wrapper'>
        <header style="background-image:url(../images/activites.jpg)">
          <?php
          if(empty($_SESSION['pseudo'])){
            include("banniere_entete.php");
            include("nav.php");
          }else{
            include("banniere_entete2.php");
            include("nav.php");
          }
          ?>
        </header>
           <div id="partiecontacte">
                <h2>Nous contacter </h2>
                  <div id="partie2">
                    <form method="POST" action="../controleur/contact.php">
                    <label for="name" class="name">Nom : <input required type="text" placeholder=" Parassou" maxlength="30" class="name" name="nom" value="<?php if(isset($_POST['nom'])) { echo $_POST['nom']; } ?>"/></label></br>
                    <label for="adressemail" class="adressemail">Adresse e-mail : <input required type="email" class="adressemail" placeholder=" nom.prenom@gmail.com" maxlength="30" name="mail"  value="<?php if(isset($_POST['mail'])) { echo $_POST['mail']; } ?>"/></label></br>
                    <label for="message" class="message"> Mon message :</label> <textarea class="messages" name="message" name="message"><?php if(isset($_POST['message'])) { echo $_POST['message']; } ?></textarea></br>
         <div id="all">
         <input type="checkbox" name="conditions" class="cond1"required ><label class="cond">J'accepte les conditions d'utilisations<br></code></label>
         </div>
         <button class="envoyer" value="Envoyer" name="Envoyer"><strong>Envoyer</strong></button>
                  </form>
                  <?php
              		if(isset($msg))
              		{
              			echo $msg;
              		}
              		?>
            </div>
          </div>
          <?php
          include('bas.php');
          ?>
      </div>
    </body>
</html>
