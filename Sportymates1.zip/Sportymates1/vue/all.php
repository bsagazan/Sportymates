<?php session_start();
?>
<!DOCTYPE HTML>
<html>
    <head>
        <meta charset="utf-8"/>
        <link rel="stylesheet" type="text/css" href="http://localhost/Sportymates1/style/styleall.css"/>
        <link rel="stylesheet" href="http://localhost/Sportymates1/style/accueilv2.css" />
        <title>Tous les <?php echo $theme; ?> - Sportymates </title>
        <link rel='icon' type="image/ico" href="../images/Logo1.png"/>
    </head>
    <body>
        <div id="wrapper">
            <header style="background-image : url(../images/banniere_sport2.jpg);">
                <?php
                  if(empty($_SESSION['pseudo'])){
                        include("banniere_entete.php");
                      }else{
                        include("banniere_entete2.php");
                      }
                  ?>
                <div id="Titre">
                    <h1>Tous les <?php echo $theme; ?></h1><br>
                </div>
                <?php include("nav.php");?>
            </header>

            <section>
                <h1> Tous les groupes</h1>
                <div id="liste">
                    <?php
                    while($don = $rep->fetch())
                    {
                    ?>
                    <figure>
                      <a href="../vue/pageGroupe.php?identifiant=<?php echo $don['nomGroupe'];?>">
                          <img src="Groupes/img-Groupes/<?php echo $don['imgGroupe']; ?>" alt = <?php echo $don['nomGroupe'];?>/>
                          <figcaption>
                              <?php echo $don['nomGroupe'];?>
                          </figcaption>
                      </a>

                    </figure>

                    <?php
                    }
                    ?>
                </div>
            </section>
            <?php
            include('bas.php');
            ?>
        </div>
    </body>

</html>
