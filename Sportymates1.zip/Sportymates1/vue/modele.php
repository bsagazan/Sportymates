<?php
require_once("../modele/connect.php");

$var1 = $_GET["groupe"];
if (isset($var1)){
    $reponse = $bdd->prepare('SELECT * FROM groupe WHERE nomGroupe = ?');
    $reponse -> execute(array($var1));
    $donnees = $reponse->fetch();
    $titre = $donnees['nomGroupe'];
    $nomSport = $donnees['nomSport'];
    $niveau = $donnees['niveau'];
    $description = $donnees['description'];
    $imgGroupe = $donnees['imgGroupe'];
    $nbreMax = $donnees['nbreMax'];
    include("profil-groupe.php");
}
else{
    echo "Erreur !";
}
$reponse->closeCursor();

?>
