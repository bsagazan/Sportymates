<?php
session_start();
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <link rel="stylesheet" href="rechercheclub.css" />
        <title>Sportymates</title>
        <link rel="icon" type="image/ico" href=logo3.png />
    </head>

    <body>
        <div id="wrapper">
        <div id="hautaccueil">
            <div id="banniere_image">
                  <div id="logo">
                      <a href=accueilv2.html><img src="images/logo1.png" alt="Logo de Sportymates"/></a>
                  </div>
              <div id="inscription">
                <a href="aide.html">Aide</a>
                <a href="inscrire.html">Inscription </a>
                <a href="connecter.html">Connection</a>
              </div>
              <div id="banniere_description">
                <nav>
                    <ul>
                        <li><a href="#">A propos |</a></li>
                        <li><a href="#">Sports |</a></li>
                        <li><a href="#">Nos groupes |</a></li>
                        <li><a href="commentaire.php">Nos clubs |</a></li>
                        <li><a href="#">Forum |</a></li>
                        <li><a href="#">Aide</a></li>
                        <div id="rechercher">
                        <input  class="rech" type='text' id='recherche' name='recherche' placeholder=Rechercher... size="20" maxlength="15" >
                        <button type=submit> <img src='images/recherchericon.png' alt='image rechercher'/> </button>
                     </div>
                    </ul>
                  </nav>
               </div>
             </div>
           </div>

           <div id="titreclub">
             <h2>Nos Clubs</h2>
           </div>
           <div id='rechclub'>
             <label> Recherche avancée : </label> <input  class="rech" type='text' id='recherche' name='recherche' placeholder=Entrezdesmotscles... size="20" maxlength="15" />
             <button class='buttonrech'type=submit>Rechercher</button>
         </div>

           <div id="titresection">
                <h2>Clubs ajoutés recemment</h2>
              </div>
              <div id='clubs'>
                <div class='club1'>
                  <p>Nom </br>(94)</p>
                </div>
                <div class='club2'>
                  <p>Nom</br> (92)</p>
                </div>
                <div class='club3'>
                  <p>Nom </br>(91)</p>
                </div>
                <div class='club4'>
                  <p>Nom </br>(75)</p>
              </div>
            </div>

         <div id="ensemble">
          <div id="titregoogle">
               <h2>Google Maps</h2>
               <p>Tous les clubs</p>
         </div>
         <div id="map">
         <script>
             function initMap() {
               var mapDiv = document.getElementById('map');
               var map = new google.maps.Map(mapDiv, {
                center: {lat: 48.8534100 , lng: 2.3488000 },
                 mapTypeId:google.maps.MapTypeId.ROADMAP,
              /*  google.maps.MapTypeId.SATELLITE,
                 google.maps.MapTypeId.HYBRID,
                 google.maps.MapTypeId.TERRAIN,*/
                 zoom: 9
               });
             }
           </script>
           <script src="https://maps.googleapis.com/maps/api/js?callback=initMap"   async defer></script>
          </div>
        </div>

            <div id=footer>
              <div class="Autres pages">
                  <h2>Autres pages</h2>
                  <p><a href="#Apropos">A propos</a></br>
                  <a href="Aide.html">Aide</a></br>
                  <a href="Forum.html">Forum</a></br>
                  <a href="Copyright et mention légales">Copyright et mention légales</a></p></br>
                  <hr class="hr" />
             </div>
              <div class="Réseaux sociaux">
                     <h2>Rejoignez-nous sur</h2>
                     <a href="https://www.facebook.com/Sportymates-1116430581702970/?ref=bookmarks"><img src="images/logofacebook.jpg" alt="Logo Facebook" /></a>
                     <a href="https://twitter.com/sportymates?lang=fr"><img src="images/logotwitter.png" alt="Logo twitter" /></a>
                     <a href="https://plus.google.com/"><img src="images/logogoogleplus.png" alt="Logo google plus" /></a>
              </div>
              <div class="finfooter">
              <p>© 2016  Sportymates</p>
             </div>
         </div>

      </div>
    </body>
</html>
