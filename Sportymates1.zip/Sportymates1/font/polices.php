<?php
@font-face {
    font-family: 'anonymousregular';
    src: url('font/Anonymous-webfont.eot');
    src: url('font/Anonymous-webfont.eot?#iefix') format('embedded-opentype'),
         url('font/Anonymous-webfont.woff') format('woff'),
         url('font/Anonymous-webfont.ttf') format('truetype'),
         url('font/Anonymous-webfont.svg#anonymousregular') format('svg');
    font-weight: normal;
    font-style: normal;

}
@font-face {
    font-family: 'sf_cartoonist_hand_scitalic';
    src: url('font/SF_Cartoonist_Hand_SC_Italic-webfont.eot');
    src: url('font/SF_Cartoonist_Hand_SC_Italic-webfont.eot?#iefix') format('embedded-opentype'),
         url('font/SF_Cartoonist_Hand_SC_Italic-webfont.woff') format('woff'),
         url('font/SF_Cartoonist_Hand_SC_Italic-webfont.ttf') format('truetype'),
         url('font/SF_Cartoonist_Hand_SC_Italic-webfont.svg#sf_cartoonist_hand_scitalic') format('svg');
    font-weight: normal;
    font-style: normal;

}
@font-face {
    font-family: 'dejavu_serifitalic';
    src: url('font/DejaVuSerif-Italic-webfont.eot');
    src: url('font/DejaVuSerif-Italic-webfont.eot?#iefix') format('embedded-opentype'),
         url('font/DejaVuSerif-Italic-webfont.woff') format('woff'),
         url('font/DejaVuSerif-Italic-webfont.ttf') format('truetype'),
         url('font/DejaVuSerif-Italic-webfont.svg#dejavu_serifitalic') format('svg');
    font-weight: normal;
    font-style: normal;

}
?>
