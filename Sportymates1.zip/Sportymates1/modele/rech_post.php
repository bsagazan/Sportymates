<?php
require_once("connect.php");


$search = str_replace("+", " ", $search);
$search = str_replace(",", " ", $search);
$search = str_replace(":", " ", $search);
$search = str_replace(";", " ", $search);
$search = str_replace("-", " ", $search);
$search = str_replace("(", " ", $search);
$search = str_replace(")", " ", $search);
$search = str_replace("^", " ", $search);
$search = str_replace(".", " ", $search);
$search = str_replace("&", " ", $search);
$search = str_replace("/", " ", $search);

$search = trim($search);
$search = addslashes($search);

$tab = explode(" ", $search);
$nb_mots = count($tab);

$query_groupe =
    "SELECT nomGroupe, nomSport, nomClub, ville
    FROM groupe
    LEFT JOIN club
    ON club.idClub = groupe.idClub
    WHERE nomGroupe LIKE '%$tab[0]%'
        OR nomSport LIKE '%$tab[0]%'
        OR nomClub LIKE '%$tab[0]%'
        OR ville LIKE '%$tab[0]%'";

$query_club =
    "SELECT nomClub, adresse
    FROM club
    WHERE nomClub LIKE '%$tab[0]%'
    OR adresse LIKE '%$tab[0]%'";

$query_sport =
    "SELECT nomSport
    FROM sport
    WHERE nomSport LIKE '%$tab[0]%'";

for ($i=1; $i<$nb_mots;$i++){

    $query_groupe.=" OR nomGroupe LIKE '%$tab[$i]%'
    OR nomSport LIKE '%$tab[$i]%'
    OR nomClub LIKE '%$tab[$i]%'
    OR ville LIKE '%$tab[$i]%'";

    $query_club.=" OR nomClub LIKE '%$tab[$i]%'
    OR adresse LIKE '%$tab[$i]%'";

    $query_sport.=" OR nomSport LIKE '%$tab[$i]%'";

}


$rep_groupe = $bdd->query($query_groupe);
$nb_result_groupe = $rep_groupe->rowCount();

$rep_club = $bdd->query($query_club);
$nb_result_club = $rep_club->rowCount();

$rep_sport = $bdd->query($query_sport);
$nb_result_sport = $rep_sport->rowCount();

$nbreTotal = $nb_result_groupe + $nb_result_club + $nb_result_sport;
/*if($nb_result_groupe != 0){
    echo "Il y a ".$nb_result_groupe;
    if($nb_result_groupe == 1){echo " résultat ";}
    else{echo " résultats ";}
    while($donnees = $rep_groupe->fetch()){
        echo $donnees['nomGroupe'].' <br>';
        echo $donnees['nomSport'].' <br>';
        echo $donnees['nomClub'].' <br>';
        echo $donnees['ville'].' <br>';
    }
}*/




?>
