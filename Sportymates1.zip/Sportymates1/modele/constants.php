<!DOCTYPE html>
<!-- Encodage en utf-8, en XHTML -->
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- Encodage en utf-8, en HTML 5 -->
<meta charset="utf-8" />
<?php
define('VISITEUR',1);
define('INSCRIT',2);
define('MODO',3);
define('ADMIN',4);
?>
<?php
define('ERR_IS_CO','Vous ne pouvez pas accéder à cette page si vous n\'êtes pas connecté');
?>
