<?php
'<body>
	<div id="banniere"></div>
<div id="menu">        
<div class="element_menu">
<h3>Mes options</h3>
<ul>
<li>Page 1</li>
<li>Page 2</li>
</ul>
</div>       
<div class="element_menu">
<h3>Navigation</h3>
<ul>
<li>Page 1</li>
<li>Page 2</li>
</ul>
</div>        
</div>
<div id="corps_forum">
</body>'
?>
