
<?php
require_once("../modele/connect.php");

	$club=$_GET['club'];

	$reponse = $bdd->prepare('DELETE FROM club WHERE idClub =?');
	$reponse->execute(array($club));
	header('Location: ../vue/admin4.php');
?>
