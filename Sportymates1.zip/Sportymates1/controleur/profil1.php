<?php
session_start();
require_once("../modele/connect.php");

if(isset($_GET['id']) AND $_GET['id'] > 0) {
   $getid = intval($_GET['id']);
   $requser = $bdd->prepare('SELECT * FROM groupeinscrit WHERE pseudo = ?');
   $requser->execute(array($getid));
   $userinfo = $requser->fetch();
?>
<html>
   <head>
      <title>Mon profil</title>
      <meta charset="utf-8">
      <link rel="stylesheet" href="../style/accueil2.css" />
      <link rel="stylesheet" href="../style/profil.css" />
   </head>
   <body>
     <div id='wrapper'>
       <header style="background-image:url(../images/profil3.jpg)">
           <?php
           include("../vue/banniere_entete2.php");
           include("../vue/nav.php");
           ?>
       </header>
      <div align="center">
        <br /><br />
         <h2>Profil de <?php echo $userinfo['pseudo']; ?></h2>
         <br />
         <?php
         if(!empty($userinfo['photodeprofil']))
         {
          ?>
          <img width="150" src="membres/photodeprofil/<?php echo $userinfo['photodeprofil'];?>"/>
         <?php
          }
         ?>
         <br /><br />
         <?php
         if(!empty($userinfo['nomGroupe']))
         {
          ?>
          <strong>Nom : </strong><?php echo $userinfo['nomGroupe']; ?>
         <?php
          }
         ?>
         <br /><br />


         <br />
         <input class="boutons" type="submit" value="Données personnelles" onClick="window.location = <?php"profil.php?id=".$_SESSION['id']?>"></code>
         <input class="boutons" type="submit" value="Mes groupes,clubs,sports" onClick="window.location =  <?php"profil1.php?id=".$_SESSION['id']?>"></code>
         <input class="boutons" type="submit" value="Planning" onClick="window.location = ''"></code>
         <input class="boutons" type="submit" value="Editer mon profil" onClick="window.location = 'editionprofil.php'"></code>
         <input class="boutons" type="submit" value="Se déconnecter" onClick="window.location = 'deconnexion.php'"></code>
         <input class="boutons" type="submit" value="Retourner à l'accueil" onClick="window.location = '../vue/accueilv3.php'"></code>

         <?php
         }
         ?>
         <br /><br />
      </div>
    </div>
   </body>
   <?php
   include("../vue/bas.php");
   ?>
</html>
<?php
}
?>
