
<?php
 require_once("../modele/connect.php");

	$pseudo=$_GET['pseudo'];

	$reponse = $bdd->prepare('DELETE FROM membres WHERE pseudo =?');
	$reponse->execute(array($pseudo));
	header('Location: ../vue/admin2.php');
?>
