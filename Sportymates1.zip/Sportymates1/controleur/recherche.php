<?php


if (isset($_POST['champ']) && $_POST['champ'] != NULL){
    $search = ($_POST['champ']);
    include("../modele/rech_post.php");
    $msgResultat="Vous avez effectué une recherche pour <strong>".$_POST["champ"]."</strong>.";
    if(isset($_GET['theme'])){
        if($_GET['theme']=="groupe"){
            if($nb_result_groupe !=0){
                if ($nb_result_groupe == 1){
                    $msgResultat.=" Nous avons trouvé ".$nb_result_groupe." résultat. </p>";
                }
                else{
                    $msgResultat.= " Nous avons trouvé ".$nb_result_groupe." résultats. </p>";
                }

            }
            else{
                $msgResultat.= " Désolé, aucun résultat n'a été trouvé.";
            }
        }

        if($_GET['theme']=="club"){
            if($nb_result_club !=0){
                if ($nb_result_club == 1){
                    $msgResultat.=" Nous avons trouvé ".$nb_result_club." résultat. </p>";
                }
                else{
                    $msgResultat.= " Nous avons trouvé ".$nb_result_club." résultats. </p>";
                }

            }
            else{
                $msgResultat.= " Désolé, aucun résultat n'a été trouvé.";
            }
        }

        if($_GET['theme']=="sport"){
            if($nb_result_sport !=0){
                if ($nb_result_sport == 1){
                    $msgResultat.=" Nous avons trouvé ".$nb_result_sport." résultat. </p>";
                }
                else{
                    $msgResultat.= " Nous avons trouvé ".$nb_result_sport." résultats. </p>";
                }

            }
            else{
                $msgResultat.= " Désolé, aucun résultat n'a été trouvé.";
            }
        }
    }
    else{
        if($nbreTotal != 0){
            if ($nbreTotal == 1){
                $msgResultat.=" Nous avons trouvé ".$nbreTotal." résultat. </p>";
            }
            else{
                $msgResultat.= " Nous avons trouvé ".$nbreTotal." résultats. </p>";
            }

        }
        else{
            $msgResultat.= " Désolé, aucun résultat n'a été trouvé.";
        }
    }
}
else{
    $msgResultat="Vous n'avez rien saisis, veuillez réessayer.";
}
include("../vue/vue_recherche.php");

?>
