<?php

    if(ISSET($_POST['inscription']))
{

//On créer les variables
$nomUtilisateur =htmlentities(trim($_POST['nomUtilisateur']));
$motDePasse = htmlentities(trim($_POST['motDePasse']));
$motDePasse = hash("sha256", $motDePasse);
$dbname = "sportymates";
$host='localhost';
$user='root';
$pass='';

if($nomUtilisateur&&$motDePasse)
{
  $bdd = new PDO("mysql:host=$host;dbname=$dbname", "$user", "$pass");
  $bdd->query("SET NAMES UTF8");
  $req = $bdd->prepare('INSERT INTO membre VALUES ($nomUtilisateur,$motDePasse)');
  die("Inscription terminée <a href='login.php'>connectez</a> vous");
}
else echo "Veuillez saisir tous les champs";
}
?>
