<?php
//Connexion à la BDD
require_once("../modele/connect.php");
//require_once("../Modele/Aide/rubrique.php");

if (isset($_GET['rub'])){
    $rep = $bdd->query('SELECT question,reponse FROM rubrique WHERE categorie="'.$_GET['rub'].'"');
    include("../vue/rubrique.php");
}
else{
    include_once("../vue/pageaide.php");
}

?>
