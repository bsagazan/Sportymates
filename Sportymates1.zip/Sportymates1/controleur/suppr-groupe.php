
<?php
require_once("../modele/connect.php");

	$pseudo=$_GET['pseudo'];

	$reponse = $bdd->prepare('DELETE FROM groupe WHERE nomGroupe =?');
	$reponse->execute(array($pseudo));
	header('Location: ../vue/admin1.php');
?>
