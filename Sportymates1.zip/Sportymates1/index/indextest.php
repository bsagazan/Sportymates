<?php
    session_start();
    require("modele/connect.php");
  //  require("vue/commun.php");

    if(!isset($_SESSION["pseudo"])){ // L'utilisateur n'est pas connecté
        include("controleur/connexion2.php"); // On utilise un controleur secondaire pour éviter d'avoir un fichier index.php trop gros
    } else { // L'utilisateur est connecté
        if(isset($_GET['cible'])) { // on regarde la page où il veut aller
            if($_GET['cible'] == 'accueil'){
                include("vue/accueilv3.php");
            } else if ($_GET['cible'] == "etape1"){
                include("modele/utilisateurs.php");
                $reponse = utilisateurs($db);
                include("vue/etape1.php");
            } else if ($_GET['cible'] == "etape2"){
                include("vue/etape2.php");
            } else if ($_GET['cible'] == "etape3"){
                include("vue/etape3.php");
           } else if ($_GET['cible'] == "deconnexion"){
                // Détruit toutes les variables de session
                $_SESSION = array();
                if (isset($_COOKIE[session_name()])) {
                    setcookie(session_name(), '', time()-42000, '/');
                }
                session_destroy();
                include("vue/nonconnecte.php");
            }
        } else { // affichage par défaut
                include("vue/accueilv2.php");
        }
    }
